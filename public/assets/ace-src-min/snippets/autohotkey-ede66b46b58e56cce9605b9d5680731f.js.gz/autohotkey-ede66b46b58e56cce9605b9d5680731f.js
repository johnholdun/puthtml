define("ace/snippets/autohotkey",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="autohotkey"})
;
