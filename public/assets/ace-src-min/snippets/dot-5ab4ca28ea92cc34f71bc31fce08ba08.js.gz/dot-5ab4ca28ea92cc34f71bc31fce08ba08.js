define("ace/snippets/dot",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="dot"})
;
