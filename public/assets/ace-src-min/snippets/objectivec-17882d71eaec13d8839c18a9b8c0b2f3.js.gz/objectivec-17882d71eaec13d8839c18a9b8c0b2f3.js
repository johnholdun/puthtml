define("ace/snippets/objectivec",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="objectivec"})
;
