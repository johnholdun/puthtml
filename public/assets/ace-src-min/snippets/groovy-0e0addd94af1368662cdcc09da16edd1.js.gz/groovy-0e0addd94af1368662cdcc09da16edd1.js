define("ace/snippets/groovy",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="groovy"})
;
