define("ace/snippets/csharp",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="csharp"})
;
