define("ace/snippets/scad",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="scad"})
;
