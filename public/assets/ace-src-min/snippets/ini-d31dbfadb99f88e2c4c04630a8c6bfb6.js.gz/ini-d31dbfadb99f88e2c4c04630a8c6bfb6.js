define("ace/snippets/ini",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="ini"})
;
