define("ace/snippets/rdoc",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="rdoc"})
;
