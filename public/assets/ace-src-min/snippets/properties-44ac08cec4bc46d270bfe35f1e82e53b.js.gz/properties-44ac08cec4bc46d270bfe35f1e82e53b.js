define("ace/snippets/properties",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="properties"})
;
