define("ace/snippets/scala",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="scala"})
;
