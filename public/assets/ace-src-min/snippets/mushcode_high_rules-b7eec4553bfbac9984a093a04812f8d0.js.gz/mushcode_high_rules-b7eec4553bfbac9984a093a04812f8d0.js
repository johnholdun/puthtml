define("ace/snippets/mushcode_high_rules",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="mushcode_high_rules"})
;
