define("ace/snippets/lisp",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="lisp"})
;
