define("ace/snippets/svg",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="svg"})
;
