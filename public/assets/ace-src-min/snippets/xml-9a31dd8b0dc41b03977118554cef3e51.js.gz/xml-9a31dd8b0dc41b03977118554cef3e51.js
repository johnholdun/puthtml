define("ace/snippets/xml",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="xml"})
;
