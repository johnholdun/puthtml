define("ace/snippets/soy_template",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="soy_template"})
;
