define("ace/snippets/rust",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="rust"})
;
