define("ace/snippets/space",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="space"})
;
