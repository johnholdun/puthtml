define("ace/snippets/cobol",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="cobol"})
;
