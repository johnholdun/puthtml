define("ace/snippets/xquery",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="xquery"})
;
