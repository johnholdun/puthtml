define("ace/snippets/d",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="d"})
;
