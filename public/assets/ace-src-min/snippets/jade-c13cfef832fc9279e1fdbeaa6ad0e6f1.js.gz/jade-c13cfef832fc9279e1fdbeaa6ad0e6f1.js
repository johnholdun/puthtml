define("ace/snippets/jade",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="jade"})
;
