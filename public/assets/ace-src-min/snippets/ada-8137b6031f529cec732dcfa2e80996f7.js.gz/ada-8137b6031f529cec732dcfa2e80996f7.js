define("ace/snippets/ada",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="ada"})
;
