define("ace/snippets/ftl",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="ftl"})
;
