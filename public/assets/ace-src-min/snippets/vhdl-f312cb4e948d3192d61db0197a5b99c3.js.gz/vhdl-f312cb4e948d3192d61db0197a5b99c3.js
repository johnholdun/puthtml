define("ace/snippets/vhdl",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="vhdl"})
;
