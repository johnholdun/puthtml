define("ace/snippets/twig",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="twig"})
;
