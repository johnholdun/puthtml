define("ace/snippets/glsl",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="glsl"})
;
