define("ace/snippets/typescript",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="typescript"})
;
