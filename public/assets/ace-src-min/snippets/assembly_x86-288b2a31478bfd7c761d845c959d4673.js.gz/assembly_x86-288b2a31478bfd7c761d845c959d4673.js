define("ace/snippets/assembly_x86",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="assembly_x86"})
;
