define("ace/snippets/liquid",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="liquid"})
;
