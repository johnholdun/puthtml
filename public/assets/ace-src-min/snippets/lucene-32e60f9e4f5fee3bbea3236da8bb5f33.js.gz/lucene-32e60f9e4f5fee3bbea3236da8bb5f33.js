define("ace/snippets/lucene",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="lucene"})
;
