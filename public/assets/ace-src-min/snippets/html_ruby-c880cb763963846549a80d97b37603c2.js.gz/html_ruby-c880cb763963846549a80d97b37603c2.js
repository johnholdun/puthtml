define("ace/snippets/html_ruby",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="html_ruby"})
;
