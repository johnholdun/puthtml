define("ace/snippets/ocaml",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="ocaml"})
;
