define("ace/snippets/json",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="json"})
;
