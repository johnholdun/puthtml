define("ace/snippets/julia",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="julia"})
;
