define("ace/snippets/pascal",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="pascal"})
;
