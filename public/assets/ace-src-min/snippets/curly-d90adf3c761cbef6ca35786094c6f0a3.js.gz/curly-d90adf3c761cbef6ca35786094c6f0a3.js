define("ace/snippets/curly",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="curly"})
;
