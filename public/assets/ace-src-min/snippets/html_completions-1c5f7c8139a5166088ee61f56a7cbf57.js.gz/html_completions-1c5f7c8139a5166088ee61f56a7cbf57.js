define("ace/snippets/html_completions",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="html_completions"})
;
