define("ace/snippets/jsoniq",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="jsoniq"})
;
