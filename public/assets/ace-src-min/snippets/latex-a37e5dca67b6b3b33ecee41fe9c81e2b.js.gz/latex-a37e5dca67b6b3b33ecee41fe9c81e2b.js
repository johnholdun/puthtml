define("ace/snippets/latex",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="latex"})
;
