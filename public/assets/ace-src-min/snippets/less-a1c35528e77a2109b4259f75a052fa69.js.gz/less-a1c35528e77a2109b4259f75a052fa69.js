define("ace/snippets/less",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="less"})
;
