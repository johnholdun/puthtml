define("ace/snippets/asciidoc",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="asciidoc"})
;
