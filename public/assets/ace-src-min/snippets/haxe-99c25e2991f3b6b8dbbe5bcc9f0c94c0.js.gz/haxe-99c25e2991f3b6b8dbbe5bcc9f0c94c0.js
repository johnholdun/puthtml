define("ace/snippets/haxe",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="haxe"})
;
