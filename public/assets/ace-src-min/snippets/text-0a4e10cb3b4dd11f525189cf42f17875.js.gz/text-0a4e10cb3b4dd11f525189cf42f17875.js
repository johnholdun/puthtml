define("ace/snippets/text",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="text"})
;
