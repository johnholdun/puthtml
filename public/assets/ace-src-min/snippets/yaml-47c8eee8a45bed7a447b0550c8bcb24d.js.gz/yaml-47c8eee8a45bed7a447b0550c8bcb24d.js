define("ace/snippets/yaml",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="yaml"})
;
