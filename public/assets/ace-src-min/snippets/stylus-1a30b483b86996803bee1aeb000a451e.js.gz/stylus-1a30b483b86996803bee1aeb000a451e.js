define("ace/snippets/stylus",["require","exports","module"],function(e,t,n){t.snippetText="",t.scope="stylus"})
;
